﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace projjjjj
{
    public static class VehicleValidator
    {
        // ── Validation Result (same pattern as CustomerValidator) ──────────────
        public class ValidationResult
        {
            public bool IsValid { get; set; } = true;
            public List<string> Errors { get; set; } = new List<string>();

            public void AddError(string message)
            {
                IsValid = false;
                Errors.Add(message);
            }

            public string ErrorSummary => string.Join("\n", Errors);
        }

        // ── Main Validator ─────────────────────────────────────────────────────
        public static ValidationResult Validate(Vehicle v)
        {
            var result = new ValidationResult();

            ValidatePlate(v.Plate, result);
            ValidateText(v.VehicleType, "Vehicle Type", 2, 50, result);
            ValidateText(v.Brand, "Brand", 1, 50, result);
            ValidateDailyRate(v.DailyRate, result);

            return result;
        }

        // ── Field Rules ────────────────────────────────────────────────────────
        private static void ValidatePlate(string plate, ValidationResult result)
        {
            if (string.IsNullOrWhiteSpace(plate))
            {
                result.AddError("License plate is required.");
                return;
            }

            string cleaned = plate.Trim().ToUpper();

            if (cleaned.Length < 2 || cleaned.Length > 10)
                result.AddError("License plate must be 2–10 characters.");

            if (!Regex.IsMatch(cleaned, @"^[A-Z0-9\-\s]+$"))
                result.AddError("License plate may only contain letters, digits, spaces, and dashes.");
        }

        private static void ValidateText(string value, string label, int min, int max,
                                         ValidationResult result)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                result.AddError($"{label} is required.");
                return;
            }

            int len = value.Trim().Length;
            if (len < min)
                result.AddError($"{label} must be at least {min} characters.");

            if (len > max)
                result.AddError($"{label} must not exceed {max} characters.");
        }

        private static void ValidateDailyRate(decimal rate, ValidationResult result)
        {
            if (rate <= 0)
                result.AddError("Daily rate must be greater than zero.");

            if (rate > 99999)
                result.AddError("Daily rate seems unrealistically high. Please check the value.");
        }
    }
}
