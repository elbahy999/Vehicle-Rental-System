﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projjjjj
{
    public class LogViewerForm : BaseForm
    {
        private TextBox txtViewer;
        private Button btnClear;
        private Button btnClose;

        public LogViewerForm()
        {
            this.Text = "System Error Logs";

            // Simple programmatic title banner
            Label lblTitle = new Label
            {
                BackColor = Color.FromArgb(27, 54, 93),
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(0, 0),
                Size = new Size(1000, 50),
                Text = "Central System-Wide Exception Viewer",
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Read-only text box to view the error_log.txt file contents
            txtViewer = new TextBox
            {
                BackColor = Color.White,
                Font = new Font("Consolas", 10F),
                Location = new Point(220, 75),
                Size = new Size(740, 510),
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical
            };

            btnClear = new Button
            {
                BackColor = Color.FromArgb(163, 45, 45),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.White,
                Location = new Point(220, 605),
                Size = new Size(140, 35),
                Text = "Clear Log File"
            };
            btnClear.Click += (s, e) =>
            {
                ErrorLogger.ClearLog();
                RefreshLog();
            };

            // Refresh button — reloads the log file from disk
            Button btnRefresh = new Button
            {
                BackColor = Color.FromArgb(24, 95, 165),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.White,
                Location = new Point(375, 605),
                Size = new Size(140, 35),
                Text = "Refresh"
            };
            btnRefresh.Click += (s, e) => RefreshLog();

            btnClose = new Button
            {
                BackColor = Color.FromArgb(95, 94, 90),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.White,
                Location = new Point(850, 605),
                Size = new Size(110, 35),
                Text = "Close"
            };
            btnClose.Click += (s, e) => this.Close();

            // Add elements to form layout canvas
            this.Controls.Add(lblTitle);
            this.Controls.Add(txtViewer);
            this.Controls.Add(btnClear);
            this.Controls.Add(btnRefresh);
            this.Controls.Add(btnClose);

            // Auto-refresh whenever this form becomes visible (e.g. opened from Settings)
            this.VisibleChanged += (s, e) => { if (this.Visible) RefreshLog(); };

            // Live update: whenever any part of the app logs an exception, refresh immediately
            ErrorLogger.OnLogUpdated += RefreshLog;

            // Unsubscribe when form is closed to avoid memory leaks
            this.FormClosed += (s, e) => ErrorLogger.OnLogUpdated -= RefreshLog;

            // Read log data automatically onto screen
            RefreshLog();
        }

        private void RefreshLog()
        {
            // Must update UI on the UI thread; safe to call from any context
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(RefreshLog));
                return;
            }

            string contents = ErrorLogger.GetLogContents();
            txtViewer.Text = contents;
            // Scroll to the bottom so the most recent entry is visible
            if (txtViewer.Text.Length > 0)
            {
                txtViewer.SelectionStart = txtViewer.Text.Length;
                txtViewer.ScrollToCaret();
            }
        }
    }
}