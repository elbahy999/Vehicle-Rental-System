﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace projjjjj
{
    public partial class VehicleForm : BaseForm
    {
        public VehicleForm()
        {
            InitializeComponent();
        }

        // ── Form Load ──────────────────────────────────────────────────────────
        private void VehicleForm_Load(object sender, EventArgs e)
        {
            LoadAllVehicles();
        }

        // ══════════════════════════════════════════════════════════════════════
        // LOAD – fills the DataGridView with all vehicles
        // ══════════════════════════════════════════════════════════════════════
        private void LoadAllVehicles()
        {
            List<Vehicle> vehicles = VehicleManager.GetAllVehicles();
            dgvVehicles.DataSource = vehicles;

            // Colour-code the IsAvailable column for quick visual feedback
            ColorAvailabilityRows();

            lblStatus.Text = $"{vehicles.Count} vehicle(s) loaded.";
            lblStatus.ForeColor = System.Drawing.Color.FromArgb(95, 94, 90);
        }

        // ══════════════════════════════════════════════════════════════════════
        // ADD BUTTON
        // ══════════════════════════════════════════════════════════════════════
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Vehicle newVehicle = new Vehicle
            {
                Plate = txtPlate.Text,
                VehicleType = txtVehicleType.Text,
                Brand = txtBrand.Text,
                DailyRate = decimal.TryParse(txtDailyRate.Text, out decimal rate) ? rate : 0,
                IsAvailable = chkIsAvailable.Checked
            };

            bool success = VehicleManager.AddVehicle(newVehicle);

            if (success)
            {
                lblStatus.ForeColor = System.Drawing.Color.FromArgb(15, 110, 86);
                lblStatus.Text = "Vehicle added successfully.";
                ClearFields();
                LoadAllVehicles();
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        // UPDATE BUTTON
        // ══════════════════════════════════════════════════════════════════════
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtVehicleID.Text))
            {
                MessageBox.Show("Please select a vehicle from the table first.",
                                "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Vehicle updated = new Vehicle
            {
                VehicleID = int.Parse(txtVehicleID.Text),
                Plate = txtPlate.Text,
                VehicleType = txtVehicleType.Text,
                Brand = txtBrand.Text,
                DailyRate = decimal.TryParse(txtDailyRate.Text, out decimal rate) ? rate : 0,
                IsAvailable = chkIsAvailable.Checked
            };

            bool success = VehicleManager.UpdateVehicle(updated);

            if (success)
            {
                lblStatus.ForeColor = System.Drawing.Color.FromArgb(24, 95, 165);
                lblStatus.Text = "Vehicle updated successfully.";
                ClearFields();
                LoadAllVehicles();
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        // TOGGLE AVAILABILITY BUTTON
        // Quickly flips IsAvailable without editing all fields
        // ══════════════════════════════════════════════════════════════════════
        private void btnToggleAvailability_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtVehicleID.Text))
            {
                MessageBox.Show("Please select a vehicle from the table first.",
                                "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int id = int.Parse(txtVehicleID.Text);
            // Current state is whatever the checkbox shows; we flip it
            bool newState = !chkIsAvailable.Checked;
            string label = newState ? "Available" : "Rented Out";

            bool success = VehicleManager.SetAvailability(id, newState);

            if (success)
            {
                lblStatus.ForeColor = newState
                    ? System.Drawing.Color.FromArgb(15, 110, 86)
                    : System.Drawing.Color.FromArgb(163, 45, 45);
                lblStatus.Text = $"Vehicle marked as '{label}'.";
                ClearFields();
                LoadAllVehicles();
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        // DELETE BUTTON
        // ══════════════════════════════════════════════════════════════════════
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtVehicleID.Text))
            {
                MessageBox.Show("Please select a vehicle from the table first.",
                                "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int id = int.Parse(txtVehicleID.Text);
            string name = $"{txtBrand.Text} {txtVehicleType.Text} ({txtPlate.Text})";

            DialogResult confirm = MessageBox.Show(
                $"Are you sure you want to delete \"{name}\"?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                bool success = VehicleManager.DeleteVehicle(id);
                if (success)
                {
                    lblStatus.ForeColor = System.Drawing.Color.FromArgb(163, 45, 45);
                    lblStatus.Text = $"Vehicle \"{name}\" deleted.";
                    ClearFields();
                    LoadAllVehicles();
                }
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        // CLEAR FIELDS
        // ══════════════════════════════════════════════════════════════════════
        private void btnClearFields_Click(object sender, EventArgs e)
        {
            ClearFields();
            lblStatus.ForeColor = System.Drawing.Color.FromArgb(95, 94, 90);
            lblStatus.Text = "Fields cleared.";
        }

        // ══════════════════════════════════════════════════════════════════════
        // GRID ROW CLICK – fills input fields from selected row
        // ══════════════════════════════════════════════════════════════════════
        private void dgvVehicles_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvVehicles.Rows[e.RowIndex];
            txtVehicleID.Text = row.Cells["VehicleID"].Value.ToString();
            txtPlate.Text = row.Cells["Plate"].Value.ToString();
            txtVehicleType.Text = row.Cells["VehicleType"].Value.ToString();
            txtBrand.Text = row.Cells["Brand"].Value.ToString();
            txtDailyRate.Text = row.Cells["DailyRate"].Value.ToString();
            chkIsAvailable.Checked = (bool)row.Cells["IsAvailable"].Value;

            // Update toggle button label to reflect current state
            bool avail = chkIsAvailable.Checked;
            btnToggleAvailability.Text = avail ? "Mark as Rented" : "Mark as Available";
            btnToggleAvailability.BackColor = avail
                ? System.Drawing.Color.FromArgb(163, 45, 45)
                : System.Drawing.Color.FromArgb(15, 110, 86);

            lblStatus.ForeColor = System.Drawing.Color.FromArgb(27, 54, 93);
            lblStatus.Text = $"Selected: {txtBrand.Text} {txtVehicleType.Text} — {txtPlate.Text}";
        }

        // ══════════════════════════════════════════════════════════════════════
        // Helpers
        // ══════════════════════════════════════════════════════════════════════
        private void ClearFields()
        {
            txtVehicleID.Clear();
            txtPlate.Clear();
            txtVehicleType.Clear();
            txtBrand.Clear();
            txtDailyRate.Clear();
            chkIsAvailable.Checked = true;
            btnToggleAvailability.Text = "Mark as Rented";
            btnToggleAvailability.BackColor = System.Drawing.Color.FromArgb(163, 45, 45);
        }

        private void ColorAvailabilityRows()
        {
            foreach (DataGridViewRow row in dgvVehicles.Rows)
            {
                if (row.DataBoundItem is Vehicle v)
                {
                    row.DefaultCellStyle.BackColor = v.IsAvailable
                        ? System.Drawing.Color.FromArgb(220, 255, 220)   // light green
                        : System.Drawing.Color.FromArgb(255, 230, 230);  // light red
                }
            }
        }
    }
}
