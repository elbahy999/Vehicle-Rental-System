﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace projjjjj
{
    public partial class CustomerForm : BaseForm
    {
        public CustomerForm()
        {
            InitializeComponent();
        }

        // ── Form Load ──────────────────────────────────────────────────────────
        private void CustomerForm_Load(object sender, EventArgs e)
        {
            LoadAllCustomers();
        }

        // ══════════════════════════════════════════════════════════════════════
        // LOAD – fills the DataGridView with all customers
        // ══════════════════════════════════════════════════════════════════════
        private void LoadAllCustomers()
        {
            List<Customer> customers = CustomerManager.GetAllCustomers();
            dgvCustomers.DataSource = customers;
            lblStatus.Text = $"{customers.Count} customer(s) loaded.";
        }

        // ══════════════════════════════════════════════════════════════════════
        // ADD BUTTON – inserts a new customer using the input fields
        // ══════════════════════════════════════════════════════════════════════
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Customer newCustomer = new Customer
            {
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                PhoneNumber = txtPhone.Text,
                Email = txtEmail.Text
            };

            bool success = CustomerManager.AddCustomer(newCustomer);

            if (success)
            {
                lblStatus.ForeColor = System.Drawing.Color.FromArgb(15, 110, 86);
                lblStatus.Text = "Customer added successfully.";
                ClearFields();
                LoadAllCustomers();
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        // UPDATE BUTTON – updates the selected customer with new field values
        // ══════════════════════════════════════════════════════════════════════
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCustomerID.Text))
            {
                MessageBox.Show("Please select a customer from the table first.",
                                "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Customer updated = new Customer
            {
                CustomerID = int.Parse(txtCustomerID.Text),
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                PhoneNumber = txtPhone.Text,
                Email = txtEmail.Text
            };

            bool success = CustomerManager.UpdateCustomer(updated);

            if (success)
            {
                lblStatus.ForeColor = System.Drawing.Color.FromArgb(24, 95, 165);
                lblStatus.Text = "Customer updated successfully.";
                ClearFields();
                LoadAllCustomers();
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        // DELETE BUTTON – deletes the selected customer after confirmation
        // ══════════════════════════════════════════════════════════════════════
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCustomerID.Text))
            {
                MessageBox.Show("Please select a customer from the table first.",
                                "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int id = int.Parse(txtCustomerID.Text);
            string name = txtFirstName.Text + " " + txtLastName.Text;

            DialogResult confirm = MessageBox.Show(
                $"Are you sure you want to delete \"{name}\"?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                bool success = CustomerManager.DeleteCustomer(id);
                if (success)
                {
                    lblStatus.ForeColor = System.Drawing.Color.FromArgb(163, 45, 45);
                    lblStatus.Text = $"Customer \"{name}\" deleted.";
                    ClearFields();
                    LoadAllCustomers();
                }
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        // CLEAR FIELDS BUTTON – empties all input textboxes
        // ══════════════════════════════════════════════════════════════════════
        private void btnClearFields_Click(object sender, EventArgs e)
        {
            ClearFields();
            lblStatus.ForeColor = System.Drawing.Color.FromArgb(95, 94, 90);
            lblStatus.Text = "Fields cleared.";
        }

        // ══════════════════════════════════════════════════════════════════════
        // HOME BUTTON – closes this form and returns to main dashboard
        // ══════════════════════════════════════════════════════════════════════
        // (btnHome_Click is inherited from BaseForm — it calls this.Close())

        // ══════════════════════════════════════════════════════════════════════
        // GRID ROW CLICK – fills input fields from the selected row
        // ══════════════════════════════════════════════════════════════════════
        private void dgvCustomers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvCustomers.Rows[e.RowIndex];
            txtCustomerID.Text = row.Cells["CustomerID"].Value.ToString();
            txtFirstName.Text = row.Cells["FirstName"].Value.ToString();
            txtLastName.Text = row.Cells["LastName"].Value.ToString();
            txtPhone.Text = row.Cells["PhoneNumber"].Value.ToString();
            txtEmail.Text = row.Cells["Email"].Value.ToString();

            lblStatus.ForeColor = System.Drawing.Color.FromArgb(27, 54, 93);
            lblStatus.Text = $"Selected: {txtFirstName.Text} {txtLastName.Text}";
        }

        // ══════════════════════════════════════════════════════════════════════
        // Helper – clears all input fields
        // ══════════════════════════════════════════════════════════════════════
        private void ClearFields()
        {
            txtCustomerID.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
        }
    }
}
