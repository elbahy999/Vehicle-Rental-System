﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projjjjj
{
    public static class ErrorLogger
    {
        private static readonly string logFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "error_log.txt");

        // In-memory list — always works, no file permission issues
        private static readonly List<string> _inMemoryLog = new List<string>();

        // Event fired every time a new exception is logged — LogViewerForm subscribes to this
        public static event Action OnLogUpdated;

        /// <summary>
        /// Appends the exception details to the in-memory log and to a file.
        /// </summary>
        public static void Log(Exception ex)
        {
            try
            {
                string entry = $"==================================================\r\n" +
                               $"[SYSTEM INTERRUPT RECORDED]\r\n" +
                               $"Timestamp: {DateTime.Now:yyyy-MM-dd HH:mm:ss}\r\n" +
                               $"Error:     {ex.Message}\r\n" +
                               $"Source:    {ex.TargetSite?.DeclaringType?.Name}.{ex.TargetSite?.Name}\r\n" +
                               $"==================================================\r\n\r\n";

                // Always store in memory first — this never fails
                _inMemoryLog.Add(entry);

                // Also try to persist to file (best-effort)
                try { File.AppendAllText(logFilePath, entry); } catch { }

                // Notify any open log viewer to refresh
                OnLogUpdated?.Invoke();
            }
            catch
            {
                // Fail-safe: logger must never crash the app
            }
        }

        public static string GetLogContents()
        {
            if (_inMemoryLog.Count > 0)
                return string.Concat(_inMemoryLog);

            // Fall back to file if in-memory is empty (e.g. app just opened)
            return File.Exists(logFilePath) ? File.ReadAllText(logFilePath) : "No exceptions registered.";
        }

        public static void ClearLog()
        {
            _inMemoryLog.Clear();
            if (File.Exists(logFilePath))
                try { File.Delete(logFilePath); } catch { }

            OnLogUpdated?.Invoke();
        }
    }
}