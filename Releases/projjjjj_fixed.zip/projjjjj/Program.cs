﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projjjjj
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // ══════════════════════════════════════════════════════════════════
            // MEMBER 6: SYSTEM-WIDE EXCEPTION INTERCEPTORS
            // ══════════════════════════════════════════════════════════════════

            // Catches any unexpected errors on the UI windows/forms automatically
            Application.ThreadException += new ThreadExceptionEventHandler(GlobalUIInterrupt);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            // Catches background thread or database engine connection failures
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(GlobalBackgroundInterrupt);

            Application.Run(new Form1());
        }

        // FIXED: Added 'static' keyword here so it compiles perfectly
        private static void GlobalUIInterrupt(object sender, ThreadExceptionEventArgs e)
        {
            // Automatically log the error to the text file instantly
            ErrorLogger.Log(e.Exception);

            // Instantly interrupt the user with a warning alert
            MessageBox.Show($"[System Interrupt] A runtime error occurred and was logged safely:\n\n{e.Exception.Message}",
                "System Interrupt", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private static void GlobalBackgroundInterrupt(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception ex)
            {
                ErrorLogger.Log(ex);
            }
        }
    }
}