﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace projjjjj
{
    public partial class FilterSortForm : BaseForm
    {
        // Lists
        List<Vehicle> vehicles = new List<Vehicle>();
        List<Customer> customers = new List<Customer>();
        private DataTable rentalsTable = new DataTable();

        public FilterSortForm()
        {
            InitializeComponent();

            // Table ComboBox
            cmbTable.Items.Add("Vehicles");
            cmbTable.Items.Add("Customers");
            cmbTable.Items.Add("Rentals");

            // Sort ComboBox
            cmbSort.Items.Add("A-Z");
            cmbSort.Items.Add("Z-A");

            cmbTable.SelectedIndex = 0;
            cmbSort.SelectedIndex = 0;
        }

        // =========================================
        // TABLE SELECTION CHANGED
        // =========================================
        private void cmbTable_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (cmbTable.SelectedItem == null)
                return;

            cmbFilter.Items.Clear();

            string selectedTable = cmbTable.SelectedItem.ToString();

            if (selectedTable == "Vehicles")
            {
                cmbFilter.Items.Add("All");
                cmbFilter.Items.Add("Available");
                cmbFilter.Items.Add("Not Available");
            }

            else if (selectedTable == "Customers")
            {
                cmbFilter.Items.Add("All");
            }

            else if (selectedTable == "Rentals")
            {
                cmbFilter.Items.Add("All");
                cmbFilter.Items.Add("Active");
                cmbFilter.Items.Add("Returned");
            }

            cmbFilter.SelectedIndex = 0;
        }

        // =========================================
        // APPLY BUTTON
        // =========================================
        private void btnApply_Click_1(object sender, EventArgs e)
        {
            try
            {
                string selectedTable = cmbTable.SelectedItem.ToString();

                if (selectedTable == "Vehicles")
                {
                    LoadVehicles();

                    bool? availableFilter = null;

                    if (cmbFilter.Text == "Available")
                        availableFilter = true;

                    else if (cmbFilter.Text == "Not Available")
                        availableFilter = false;

                    List<Vehicle> filtered =
                        FilterVehicles(vehicles, txtSearch.Text, availableFilter);

                    BubbleSortVehicles(filtered);

                    if (cmbSort.Text == "Z-A")
                        filtered.Reverse();

                    dgvResults.DataSource = null;
                    dgvResults.DataSource = filtered;
                }

                else if (selectedTable == "Customers")
                {
                    LoadCustomers();

                    List<Customer> filtered =
                        FilterCustomers(customers, txtSearch.Text);

                    BubbleSortCustomers(filtered);

                    if (cmbSort.Text == "Z-A")
                        filtered.Reverse();

                    dgvResults.DataSource = null;
                    dgvResults.DataSource = filtered;
                }

                else if (selectedTable == "Rentals")
                {
                    LoadRentals();

                    DataView dv = new DataView(rentalsTable);

                    string filter = cmbFilter.Text;

                    if (filter == "Active")
                    {
                        dv.RowFilter = "Status = 'Active'";
                    }
                    else if (filter == "Returned")
                    {
                        dv.RowFilter = "Status = 'Returned'";
                    }
                    else
                    {
                        dv.RowFilter = "1=1"; // All
                    }

                    dgvResults.DataSource = dv;
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log(ex);
                MessageBox.Show("Error applying filter:\n" + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // =========================================
        // LOAD VEHICLES
        // =========================================
        private void LoadVehicles()
        {
            try
            {
                vehicles.Clear();

                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT VehicleID, Plate, VehicleType, Brand, DailyRate, IsAvailable FROM Vehicles";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                        while (reader.Read())
                            vehicles.Add(new Vehicle
                            {
                                VehicleID = reader.GetInt32(0),
                                Plate = reader.GetString(1),
                                VehicleType = reader.GetString(2),
                                Brand = reader.GetString(3),
                                DailyRate = reader.GetDecimal(4),
                                IsAvailable = reader.GetBoolean(5)
                            });
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log(ex);
                throw; // re-throw so btnApply_Click catches it too
            }
        }

        // =========================================
        // FILTER VEHICLES
        // =========================================
        private List<Vehicle> FilterVehicles(
            List<Vehicle> vehicles,
            string search,
            bool? isAvailable)
        {
            List<Vehicle> result = new List<Vehicle>();

            foreach (var v in vehicles)
            {
                bool matchesSearch =
                    string.IsNullOrEmpty(search) ||
                    v.Brand.ToLower().Contains(search.ToLower()) ||
                    v.VehicleType.ToLower().Contains(search.ToLower());

                bool matchesStatus =
                    !isAvailable.HasValue ||
                    v.IsAvailable == isAvailable.Value;

                if (matchesSearch && matchesStatus)
                {
                    result.Add(v);
                }
            }

            return result;
        }

        // =========================================
        // BUBBLE SORT VEHICLES
        // =========================================
        private void BubbleSortVehicles(List<Vehicle> vehicles)
        {
            for (int i = 0; i < vehicles.Count - 1; i++)
            {
                for (int j = 0; j < vehicles.Count - i - 1; j++)
                {
                    if (string.Compare(
                        vehicles[j].Brand,
                        vehicles[j + 1].Brand) > 0)
                    {
                        Vehicle temp = vehicles[j];
                        vehicles[j] = vehicles[j + 1];
                        vehicles[j + 1] = temp;
                    }
                }
            }
        }

        // =========================================
        // LOAD CUSTOMERS
        // =========================================
        private void LoadCustomers()
        {
            try
            {
                customers.Clear();

                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT CustomerID, FirstName, LastName, PhoneNumber, Email FROM Customers";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                        while (reader.Read())
                            customers.Add(new Customer
                            {
                                CustomerID = reader.GetInt32(0),
                                FirstName = reader.GetString(1),
                                LastName = reader.GetString(2),
                                PhoneNumber = reader.GetString(3),
                                Email = reader.GetString(4)
                            });
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log(ex);
                throw;
            }
        }

        // =========================================
        // FILTER CUSTOMERS
        // =========================================
        private List<Customer> FilterCustomers(
            List<Customer> customers,
            string search)
        {
            List<Customer> result = new List<Customer>();

            foreach (var c in customers)
            {
                bool matchesSearch =
                    string.IsNullOrEmpty(search) ||
                    c.FirstName.ToLower().Contains(search.ToLower()) ||
                    c.LastName.ToLower().Contains(search.ToLower());

                if (matchesSearch)
                {
                    result.Add(c);
                }
            }

            return result;
        }

        // =========================================
        // BUBBLE SORT CUSTOMERS
        // =========================================
        private void BubbleSortCustomers(List<Customer> customers)
        {
            for (int i = 0; i < customers.Count - 1; i++)
            {
                for (int j = 0; j < customers.Count - i - 1; j++)
                {
                    if (string.Compare(
                        customers[j].FirstName,
                        customers[j + 1].FirstName) > 0)
                    {
                        Customer temp = customers[j];
                        customers[j] = customers[j + 1];
                        customers[j + 1] = temp;
                    }
                }
            }
        }

        // =========================================
        // LOAD RENTALS
        // =========================================
        private void LoadRentals()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT * FROM Rentals";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    rentalsTable = new DataTable();
                    adapter.Fill(rentalsTable);
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log(ex);
                throw;
            }
        }

        // =========================================
        // CLEAR BUTTON
        // =========================================
        private void btnClear_Click_1(object sender, EventArgs e)
        {
            txtSearch.Clear();

            cmbTable.SelectedIndex = 0;
            cmbSort.SelectedIndex = 0;
        }

        // =========================================
        // HOME BUTTON
        // =========================================
        private void btnHome_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }

}